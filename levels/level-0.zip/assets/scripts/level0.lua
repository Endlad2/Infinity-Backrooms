-- Backrooms Infinity — Level 0
-- This script only sees the sandboxed `bi` API. No filesystem/process/FFI access.

local toggled = false
local cache_taken = false

bi.events.on("level_start", function(e)
    bi.log("info", "Level 0 started: " .. e.name)
    bi.player.message("LEVEL 0 — THE LOBBY", 4.0)
end)

bi.events.on("void_fall", function(e)
    bi.log("warn", "Player stepped into unstable carpet: " .. e.id)
    bi.stats.add_sanity(-7)
    bi.player.message("The floor gives way. Something puts you back.", 2.2)
    bi.player.teleport(0.0, 1.7, 11.0)
end)

bi.events.on("flicker_switch", function(e)
    toggled = not toggled
    bi.world.set_visible("warning_panel", not toggled)
    if toggled then
        bi.player.message("The fluorescent panel dies. The hum continues.", 2.5)
    else
        bi.player.message("The panel flickers back to life.", 2.0)
    end
end)

bi.events.on("supply_cache", function(e)
    if cache_taken then
        bi.player.message("The recess is empty.", 1.6)
        return
    end
    cache_taken = true
    bi.inventory.give("almond_water", 1)
    bi.inventory.give("rice_cookie", 1)
    bi.player.message("You found Almond Water and a Rice Cookie.", 2.8)
end)

bi.events.on("strange_wall", function(e)
    bi.stats.add_sanity(-2)
    bi.player.message("The pattern repeats, but not quite correctly.", 2.5)
end)

local elapsed = 0.0
bi.events.on("tick", function(e)
    elapsed = elapsed + e.dt
    if elapsed > 45.0 then
        elapsed = 0.0
        -- A tiny ambient sanity pressure; intentionally mild for the sample level.
        bi.stats.add_sanity(-0.5)
    end
end)
